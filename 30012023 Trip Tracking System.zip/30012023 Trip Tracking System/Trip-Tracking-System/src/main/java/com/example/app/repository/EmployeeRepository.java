package com.example.app.repository;
import java.util.List;
import org.springframework.data.repository.CrudRepository;

import org.springframework.data.domain.Sort;
import org.springframework.data.jdbc.repository.query.Modifying;
//import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import com.example.app.model.Employee;
import org.springframework.http.ResponseEntity;
import org.springframework.data.repository.query.Param;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>{
	 List<Employee> findAll(Sort sort);
	 List<Employee> findByEmpID(Long empID);
	 List<Employee> findByEmpIDAndEmppwIgnoreCase(Long empID, String emppw);
	 List<Employee> findByEmpgroup(String empgroup);
//	 List<Employee> getReferenceById(ID empID);
//	@QueryHints
//	@Query("SELECT b FROM employee b WHERE b.employee_pw =:empID")
//	    List <Employee> findByEmpID(Long empID);
//	 
//	List<Employee> findByEmppw(String emppw);
}
//	@Query(value= "SELECT * FROM employee WHERE employee_id=1? AND employee_pw = '?1'", nativeQuery=true)
//      List <Employee> findByEmppw(String emppw);
//		@Query("SELECT * FROM employee WHERE employee_id=?1 AND cast (employee_pw = '?1' AS CHARACTER VARYING)")
//	      List <Employee> findByEmppw(Integer empID,String emppw);
	 
