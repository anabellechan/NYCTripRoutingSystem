package com.example.app.controller;

import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.bridge.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.example.app.model.Assets;
//import com.example.app.model.Assets;
import com.example.app.model.Employee;
//import com.example.app.repository.AssetRepository;
import com.example.app.repository.EmployeeRepository;
import com.example.app.repository.AssetRepository;
import com.jayway.jsonpath.internal.function.text.Length;
import org.slf4j.Logger;


@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
@RestController
//@Scope("session")
public class Controller {
	@Autowired
	AssetRepository AssetRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;

	@GetMapping("/hi")
	public String sayHi() {
		return "Greetings from Spring Boot!";
	}

	@GetMapping("/getall")
	public List<Employee> getAllAcc() {

		return employeeRepository.findAll();
	}
	
	
//Get Cookies for Login
	@ResponseStatus(HttpStatus.OK)
	@PostMapping("/createcookie")
	public String setCookie(HttpServletResponse response, @RequestBody Employee employee) {
		// create a cookie
		String username= String.valueOf(employee.getEmpID());
		System.out.println("Cookies "+ username);
	    Cookie cookie = new Cookie("user", username);
	    cookie.setMaxAge(7 * 24 * 60 * 60); // expires in 7 days

	    //add cookie to response
	    response.addCookie(cookie);

	    return ("Adding cookie!"+ cookie);
	}
	
	@ResponseStatus(HttpStatus.OK)
	@GetMapping("/cookies")
	public String readAllCookies(HttpServletRequest request, HttpServletResponse response) {
	    Cookie[] cookies = request.getCookies();
	    if (cookies != null) {
     response.setStatus(200);
	        return Arrays.stream(cookies)
	                .map(c -> c.getName() + "=" + c.getValue()).collect(Collectors.joining(", "));
	    }
	    else 
	    return (cookies+"");
	    
	    
	}
	
	//Deleting Cookies for Logout
		@ResponseStatus(HttpStatus.OK)
		@GetMapping("/deletecookie")
		public String delCookie(HttpServletResponse response) {
			// create a cookie
			// create a cookie
			Cookie cookie = new Cookie("user", null);
			cookie.setMaxAge(0);
			cookie.setSecure(true);
			cookie.setHttpOnly(true);
			cookie.setPath("/");

		    //add cookie to response
		    response.addCookie(cookie);

		    return ("Delete cookie!"+ cookie);
		}
	
	//Posting Login Credentials
	@PostMapping("/login")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<Employee> loginUser(@Validated @RequestBody Employee employee ) {
		Long InputID = employee.getEmpID();
		String InputPW = employee.getEmppw();
		System.out.println("Login : " + InputID +" "+ InputPW);
		List<Employee> EmpExists = employeeRepository.findByEmpIDAndEmppwIgnoreCase(InputID, InputPW);
		System.out.println("Account Match Details" + EmpExists);
		if (EmpExists.isEmpty()) {
			System.out.println("User Id or Password is wrong. Try again."); 
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		else {return ResponseEntity.ok(employee);
		}
		}
		
		
	@GetMapping("/logout")
	public String logout() {
	    return "redirect:/login";
	}
	
	@GetMapping("/dashboard")
	@ResponseStatus(HttpStatus.OK)
	public List<Employee> getEmployeeById() {

		return employeeRepository.findAll();
	}

	@GetMapping("/getuser/{IDfromURL}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<List<Employee>> getEmployeeById(@PathVariable Long IDfromURL) {
		List<Employee> employee = employeeRepository.findByEmpID(IDfromURL);
		if (employee == null)
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		else
			return ResponseEntity.ok(employee);
	}
	
	//CREATE EMPLOYEE`
	@RequestMapping(value = "/createemployee/{id}", method=RequestMethod.POST)
	@PostMapping("/createemployee/{id}")
	@ResponseStatus ( HttpStatus.OK )
	public ResponseEntity<Employee> createEmployee(@PathVariable Long id, @RequestBody Employee employee)	{
	//Check that id does not already exist in database first	
//	Long id = employee.getEmpID();
	List<Employee> EmpExists = employeeRepository.findByEmpID(id);
	if (EmpExists.isEmpty()) { //no existing employee with that ID
	employee.setEmpID(employee.getEmpID());
	employee.setEmpname(employee.getEmpname());
	employee.setEmppw(employee.getEmppw());
	employee.setEmpgroup(employee.getEmpgroup());
	employeeRepository.save(employee);
	System.out.println("Successful creation of Employee! : " + employee);
	return ResponseEntity.ok(employee);
	} else {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
	}

	
	@DeleteMapping("/delemployee/{id}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
		Employee employee = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		employeeRepository.delete(employee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@PutMapping("/edit/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employee){
		System.out.println("employee strawberries : " + employee);
		Employee employ = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		System.out.println("employee : " + employee);
		String InputPW = employee.getEmppw();
		List<Employee> IDandPWMatch = employeeRepository.findByEmpIDAndEmppwIgnoreCase(id, InputPW);
		if (IDandPWMatch.isEmpty()) {
		System.out.println("ID AND PW MATCH "+IDandPWMatch);
		employ.setEmpname(employee.getEmpname());
		employ.setEmppw(employee.getEmppw());
		employ.setEmpgroup(employee.getEmpgroup());
		Employee updatedEmployee = employeeRepository.save(employ);
		return ResponseEntity.ok(updatedEmployee);
		} else {
			System.out.println("Password in use. Please change to a new password.");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
}
	
//	@ResponseStatus(value = HttpStatus.NOT_FOUND)
//	class ApplicationUserNotFoundException extends RuntimeException {
//	 
//	    public ApplicationUserNotFoundException() {
//	    }
//	 
//	    public ApplicationUserNotFoundException(String message) {
//	        super(message);
//	    }
//	 
//	    public ApplicationUserNotFoundException(String message, Throwable cause) {
//	        super(message, cause);
//	    }
//	 
//	    public ApplicationUserNotFoundException(Throwable cause) {
//	        super(cause);
//	    }
//	 
//	    public ApplicationUserNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
//	        super(message, cause, enableSuppression, writableStackTrace);
//	    }
//	}
	@GetMapping("/getusers")
	public List<Employee> getAllIdNameGroup() {
		String empgroup = "employee";
		List<Employee> findAllByEmpgroup= employeeRepository.findByEmpgroup(empgroup);
		return findAllByEmpgroup;
	}
	
	@GetMapping("/getallassets")
	public List<Assets> getAllAssets() {

		return AssetRepository.findAll();
	}
	
	@GetMapping("/getasset/{serialno}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<List<Assets>> getAssetById(@PathVariable String serialno) {
		List<Assets> asset = AssetRepository.findByserialno(serialno);
		if (asset == null)
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		else
			return ResponseEntity.ok(asset);
	}
	
	@PutMapping("/updateasset/{serialno}")
	public ResponseEntity<Assets> UpdateAsset(@PathVariable String serialno, @RequestBody Assets assets){
		System.out.println("assets: " + assets);
		
		Assets assetbyid = AssetRepository.findByserialno(serialno).get(0);
		
		if (assetbyid != null) {
			long millis = System.currentTimeMillis(); 
			java.sql.Date date = new java.sql.Date(millis); 
			 
			// Default value: No change needed
			assetbyid.setAssetid(assetbyid.getAssetid());
			assetbyid.setSerialno(serialno);
			assetbyid.setAssetcd(assetbyid.getAssetcd());

			// Needs to be updated
			assetbyid.setAssetdesc(assets.getAssetdesc());
			assetbyid.setAssetempid(assets.getAssetempid());
			assetbyid.setAssethandover(assets.getAssethandover());
			assetbyid.setAssetstatus(assets.getAssetstatus());
	
			Assets updatedAssets = AssetRepository.save(assetbyid);
			return ResponseEntity.ok(updatedAssets);
		}
		else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
}
	
	//CREATE ASSET
	@RequestMapping(value = "/createasset", method=RequestMethod.PUT)
	@PutMapping("/createasset")
	@ResponseStatus ( HttpStatus.OK )
//	ResponseEntity<Assets>
	public Assets createAsset(@RequestBody Assets assets)	{
	System.out.println("Asset Input" + assets);
	AssetRepository.save(assets);
	System.out.println("Successful creation of Assets!: " + assets);
	return assets;
	}
	
	
	
	
	
	
	
	
	
}
