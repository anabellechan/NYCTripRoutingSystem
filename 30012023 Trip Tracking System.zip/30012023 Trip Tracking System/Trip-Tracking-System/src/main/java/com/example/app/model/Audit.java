//package com.example.app.model;
//import java.io.Serializable;
//import java.sql.Date;
//
////import java.io.Serializable;
//import javax.persistence.*;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Table;
//import lombok.Data;
//
//import org.hibernate.annotations.Immutable;
//import org.springframework.context.annotation.Scope;
//@Data
//@Scope("session")
//@Entity
//@Table(name = "audit")
//public class Audit implements Serializable {
//	@Id
//    @Column(name = "id")
//    private Long assetid;
//    
//    @Column(name = "assets_sn")
//    private String serialno;
//    
//    @Column(name = "assets_desc")
//    private String assetdesc;
//
//    @Column(name = "assets_cd")
//    private Date assetcd;
//    
//    @Column(name = "employee_id")
//    private Long assetempid;
//    
//    @Column(name = "assets_handover")
//    private Date assethandover;
//    
//    @Column(name = "assets_status")
//    private String assetstatus;
//
//    
//    public Assets() {
//    }
//    
//    public Assets(Long assetid, String serialno, String assetdesc, Date assetcd, Long assetempid, Date assethandover, String assetstatus) {
//		super();
//		this.assetid= assetid;
//		this.serialno = serialno;
//		this.assetdesc = assetdesc;
//		this.assetcd = assetcd;
//		this.assetempid = assetempid;
//		this.assethandover = assethandover;
//		this.assetstatus = assetstatus;
//	}
//    
//    
//	
//	public Long getAssetid() {
//		return assetid;
//	}
//
//	public void setAssetid(Long assetid) {
//		this.assetid = assetid;
//	}
//
//	@Override
//	public String toString() {
//		return "Tutorial [ A_ID=" + assetid + ", A_SN=" + serialno + ", A_Desc=" + assetdesc+ ", A_CD=" + assetcd + ", Emp_ID=" + assetempid + ", A_HO=" + assethandover + ", A_Status=" + assetstatus +"]";
//	}
//    
//}

