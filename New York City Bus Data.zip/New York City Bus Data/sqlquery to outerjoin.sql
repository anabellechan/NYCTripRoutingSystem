INSERT INTO busdatafull
SELECT * FROM nycdatafull
FULL OUTER JOIN trip on nycdatafull.vehicleref = trip.vehicleref
and nycdatafull.destinationname = trip.destinationname
and nycdatafull.originname = trip.originname
and nycdatafull.linename = trip.linename
and nycdatafull.recordeddate= trip.date
and nycdatafull.directionref= trip.directionref;
