package com.example.app.model;
import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

import org.springframework.context.annotation.Scope;
import jakarta.persistence.*;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Data
@Scope("session")
@Entity
@Table(name = "trip")
public class Trip implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "tripno")
	private Long tripID;

	@Column(name = "date")
	private Date date;

	@Column(name = "originname")
	private String originName;

	@Column(name = "destinationname")
	private String destinationName;
	
	@Column(name = "linename")
	private String lineName;
	
	@Column(name = "vehicleref")
	private String vehicleRef;
	
	@Column(name = "directionref")
	private Integer directionRef;
	
	@Column(name = "noofstops")
	private Integer no_ofStops;
	
	public Trip(){
    }
	
	public Trip(Long tripID, Date date, String originName, String destinationName, String lineName, String vehicleRef, Integer directionRef, Integer no_ofStops) {
		super();
		this.tripID = tripID;
		this.date = date;
		this.originName = originName;
		this.destinationName = destinationName;
		this.lineName = lineName;
		this.vehicleRef = vehicleRef;
		this.directionRef = directionRef;
		this.no_ofStops = no_ofStops;
	}

	public Long gettripID() {
		return tripID;
	}

	public void settripID(Long tripID) {
		this.tripID = tripID;
	}
	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getoriginName() {
		return originName;
	}
	
	public void setoriginName(String originName) {
		this.originName = originName;
	}

	public String getdestinationName() {
		return destinationName;
	}

	public void setdestinationName(String destinationName) {
		this.destinationName = destinationName;
	}
	
	public String getlineName() {
		return lineName;
	}

	public void setlineName(String lineName) {
		this.lineName = lineName;
	}

	public String getvehicleRef() {
		return vehicleRef;
	}

	public void setvehicleRef(String vehicleRef) {
		this.vehicleRef = vehicleRef;
	}
	
	public Integer getdirectionRef() {
		return directionRef;
	}

	public void setdirectionRef(Integer directionRef) {
		this.directionRef = directionRef;
	}

	public Integer getno_ofStops() {
		return no_ofStops;
	}

	public void setno_ofStops(Integer no_ofStops) {
		this.no_ofStops = no_ofStops;
	}
	
	@Override
	public String toString() {
		return "Tutorial [ id=" + tripID + ", origin name=" + originName + ",destination=" + destinationName + ", line name=" + lineName + ", vehicle ref=" + vehicleRef + ", directionref=" + directionRef + ", no. of stops=" + no_ofStops +"]";
	}
	
}
