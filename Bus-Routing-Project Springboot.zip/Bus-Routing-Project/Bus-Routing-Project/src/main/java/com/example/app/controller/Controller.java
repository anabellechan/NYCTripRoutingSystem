package com.example.app.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import java.util.List;
import com.example.app.model.Trip;
import com.example.app.repository.BusRepository;

@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
@RestController
public class Controller {
	@Autowired
	BusRepository BusRepository;
	
	@GetMapping("/hi")
	public String sayHi() {
		return "Greetings from Spring Boot!";
	}
	@GetMapping("/getall")
	public List<Trip> getAll() {

		return BusRepository.findAll();
	}

	@GetMapping("/getTripbyID/{IDfromURL}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<List<Trip>> getTripById(@PathVariable Long IDfromURL) {
		List<Trip> trip = BusRepository.findByTripID(IDfromURL);
		if (trip == null)
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		else
			return ResponseEntity.ok(trip);
	}
	
	@GetMapping("/getTripsbyLinename/{linefromURL}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<List<Trip>> getTripByLine(@PathVariable String linefromURL) {
		List<Trip> trips = BusRepository.findByLineName(linefromURL);
		if (trips == null)
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		else
			return ResponseEntity.ok(trips);
	}
	
}
