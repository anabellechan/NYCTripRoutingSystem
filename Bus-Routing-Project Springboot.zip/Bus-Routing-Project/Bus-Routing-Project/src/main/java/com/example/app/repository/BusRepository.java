package com.example.app.repository;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Sort;
import com.example.app.model.Trip;

@Repository
public interface BusRepository extends JpaRepository<Trip,Long>{
	List<Trip> findAll(Sort sort);
	List<Trip> findByTripID(Long tripNo);
	List<Trip> findByLineName(String iDfromURL);
}
